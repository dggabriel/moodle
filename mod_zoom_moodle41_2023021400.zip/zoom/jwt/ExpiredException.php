<?php
// phpcs:ignoreFile

namespace Firebase\JWT;

class ExpiredException extends \UnexpectedValueException
{
}
