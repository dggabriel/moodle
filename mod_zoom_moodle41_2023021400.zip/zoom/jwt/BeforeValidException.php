<?php
// phpcs:ignoreFile

namespace Firebase\JWT;

class BeforeValidException extends \UnexpectedValueException
{
}
