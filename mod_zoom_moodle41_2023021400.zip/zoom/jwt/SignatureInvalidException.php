<?php
// phpcs:ignoreFile

namespace Firebase\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{
}
